﻿namespace Santase.Logic.Cards
{
    public enum CardType
    {
        Nine = 9,
        Ten = 10,
        Jack = 11,
        Queen = 12,
        King = 13,
        Ace = 1,
    }
}
