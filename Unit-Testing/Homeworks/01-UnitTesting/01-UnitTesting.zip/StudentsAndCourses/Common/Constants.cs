﻿namespace StudentsAndCourses.Common
{
    public static class Constants
    {
        public const uint MaxStudentNumber = 99999;
        public const uint MinStudentNumber = 10000;
        public const uint MaxStudentsPerCourse = 30;

    }
}
