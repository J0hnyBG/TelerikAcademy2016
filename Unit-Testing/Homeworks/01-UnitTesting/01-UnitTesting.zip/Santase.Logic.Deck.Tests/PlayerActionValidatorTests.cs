﻿namespace Santase.Logic.Tests
{
    using System.Collections.Generic;
    using NUnit.Framework;
    using Moq.AutoMock;
    using Moq;

    using Santase.Logic.Cards;
    using Santase.Logic.Players;
    using Santase.Logic.RoundStates;
	[TestFixture]
    public class PlayerActionValidatorTests
    {
        //TODO: Optional
    }
}
