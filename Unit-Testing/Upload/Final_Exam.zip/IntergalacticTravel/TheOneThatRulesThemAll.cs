﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntergalacticTravel
{
    public class TheOneThatRulesThemAll
    {
        public void RuleThem()
        {
            
            // Create galactic map

            // Create units
        
            // Give them some resources

            // Set their location

            // Teleport them
        }
    }
}
