using System;
using System.Web.UI;

namespace _04_ExtendedEmployees
{
    public partial class Site_Mobile : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}