﻿using System;

using _02_Employees;

namespace _04_ExtendedEmployees
{
    public partial class _Default : EmployeeBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}