using System;
using System.Web.UI;

namespace _03_XMLTree
{
    public partial class Site_Mobile : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}