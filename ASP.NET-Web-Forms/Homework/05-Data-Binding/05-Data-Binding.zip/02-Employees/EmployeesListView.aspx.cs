﻿using System;

namespace _02_Employees
{
    public partial class EmployeesListView : EmployeeBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}