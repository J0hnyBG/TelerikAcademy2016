﻿namespace _01_Cars.Models.Enums
{
    public enum EngineType
    {
        Gas,
        Gasoline,
        Diesel
    }
}
