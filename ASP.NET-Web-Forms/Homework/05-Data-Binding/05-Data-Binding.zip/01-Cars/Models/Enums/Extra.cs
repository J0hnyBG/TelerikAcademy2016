﻿namespace _01_Cars.Models.Enums
{
    public enum Extra
    {
        ABS,
        GPS,
        Catalyst,
        LED,
        Alarm,
        Immobilizer,
        Rollbar,
        Stereo,
        AYC,
        TCS,
        Insurance
    }
}
