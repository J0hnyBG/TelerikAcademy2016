﻿namespace _01_Cars.CustomEventArgs.Contracts
{
    public interface IProducerSelectionEventArgs
    {
        string SelectedProducer { get; set; }
    }
}
