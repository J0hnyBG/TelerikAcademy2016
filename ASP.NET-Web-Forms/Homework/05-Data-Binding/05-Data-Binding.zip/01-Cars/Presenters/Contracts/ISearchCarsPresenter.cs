﻿using WebFormsMvp;

using _01_Cars.Views;

namespace _01_Cars.Presenters.Contracts
{
    public interface ISearchCarsPresenter : IPresenter<ISearchCarsView>
    {
    }
}
