namespace _01_WebForms.Common.Contracts
{
    public interface ISumatorPageView
    {
        string TextBox1Text { get; set; }
        string TextBox2Text { get; set; }
        string ResultText { get; set; }
    }
}