﻿namespace _01_WebForms.Common.Contracts
{
    public interface IView<T>
    {
        T View { get; set; }
    }
}
