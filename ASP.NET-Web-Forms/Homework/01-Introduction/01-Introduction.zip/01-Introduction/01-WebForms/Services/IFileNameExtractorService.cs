﻿namespace _01_WebForms.Services
{
    public interface IFileNameExtractorService
    {
        string ExtractFileNameFromLocalPath(string path);
    }
}
