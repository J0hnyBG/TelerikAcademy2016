﻿namespace _01_Links.UserControls
{
    public class MenuLink : IMenuLink
    {
        public string Url { get; set; }

        public string Title { get; set; }
    }
}