namespace _01_Links.UserControls
{
    public interface IMenuLink
    {
        string Url { get; set; }

        string Title { get; set; }
    }
}