﻿namespace _05_Calculator.Calculator
{
    public class Calculator
    {
    }
}