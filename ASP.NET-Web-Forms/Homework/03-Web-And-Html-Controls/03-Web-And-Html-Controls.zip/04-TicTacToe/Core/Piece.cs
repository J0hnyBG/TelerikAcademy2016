﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _04_TicTacToe.Core
{
    public enum Piece
    {
        Empty,
        X,
        O
    }
}