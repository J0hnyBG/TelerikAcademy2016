CSS Overview - Homework
============

### Problem 1. Ticket CSS
*	Create the following page section using HTML and external CSS (no inline styles).
*	Use a table or a definition list (the layout will be different).

![picture1](https://cloud.githubusercontent.com/assets/3619393/7183745/e7c7f452-e461-11e4-82d9-86fd12a266f6.png)

### Problem 2. International Employees
*	Create the following Web page using external CSS styles.

![picture2](https://cloud.githubusercontent.com/assets/3619393/7183744/e7c7704a-e461-11e4-80f5-71015ea9fd99.png)

### Problem 3. Forum Posts
*	Create a web page using the design and the HTML markup in [homework.html](https://github.com/TelerikAcademy/CSS/blob/master/01.%20CSS-Overview/demos/homework.html).

![picture3](https://cloud.githubusercontent.com/assets/3619393/7183746/e7c83d36-e461-11e4-8cb3-eb252752f0b4.png)