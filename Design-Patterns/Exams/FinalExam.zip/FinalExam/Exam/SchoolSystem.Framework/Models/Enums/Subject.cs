﻿namespace SchoolSystem.Framework.Models.Enums
{
    public enum Subject
    {
        Bulgarian = 0,
        English = 1,
        Math = 2,
        Programming = 3
    }
}
