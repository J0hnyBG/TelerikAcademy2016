﻿namespace Strategy.Robots.Behaviours.Contracts
{
    public interface IBehaviour
    {
        void Act(string name);
    }
}
