﻿namespace ChainOfResponsibility.Loggers.Enums
{
    public enum LogLevel
    {
        Info,
        Warning,
        CriticalError
    }
}