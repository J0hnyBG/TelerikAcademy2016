﻿namespace Dealership.Engine.Contracts
{
    public interface IEngine
    {
        void Start();

        void Reset();
    }
}
