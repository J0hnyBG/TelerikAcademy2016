﻿namespace _10_ADO.Net.Models
{
    public class PersonScore
    {
        public string Name { get; set; }
        public string Score { get; set; }
    }
}
