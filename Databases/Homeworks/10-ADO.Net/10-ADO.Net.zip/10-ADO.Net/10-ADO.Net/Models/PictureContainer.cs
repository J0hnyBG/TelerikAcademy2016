﻿namespace _10_ADO.Net.Models
{
    public class PictureContainer
    {
        public byte[] Picture { get; set; }
    }
}
