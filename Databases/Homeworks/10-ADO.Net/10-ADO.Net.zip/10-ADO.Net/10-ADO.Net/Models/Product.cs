﻿namespace _10_ADO.Net.Models
{
    public class Product
    {
        public string ProductName { get; set; }
    }
}
