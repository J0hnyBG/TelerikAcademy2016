﻿namespace _10_ADO.Net.Models
{
    public class CategoryWithProducts
    {
        public string CategoryName { get; set; }
        public string Products { get; set; }
    }
}
