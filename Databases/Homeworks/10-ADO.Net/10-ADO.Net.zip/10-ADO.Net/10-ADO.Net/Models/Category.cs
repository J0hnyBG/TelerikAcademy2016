﻿namespace _10_ADO.Net.Models
{
    public class Category
    {
        public string CategoryName { get; set; }
        public string Description { get; set; }
    }
}
