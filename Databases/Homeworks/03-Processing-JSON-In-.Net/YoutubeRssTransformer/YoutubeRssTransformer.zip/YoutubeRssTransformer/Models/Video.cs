﻿namespace YoutubeRssTransformer.Models
{
    public class Video
    {
        public string Url { get; set; }

        public string Title { get; set; }
    }
}
