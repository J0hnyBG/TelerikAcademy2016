﻿namespace SuperheroesUniverse.Importer.Dto
{
    using System.Collections.Generic;

    public class SuperheroData
    {
        public ICollection<Superhero> Data { get; set; }
    }
}
