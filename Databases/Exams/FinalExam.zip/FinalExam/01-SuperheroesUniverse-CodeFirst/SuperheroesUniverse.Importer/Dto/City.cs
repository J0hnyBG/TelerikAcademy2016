﻿namespace SuperheroesUniverse.Importer.Dto
{
    public class City
    {
        public string Name { get; set; }
        public string Country { get; set; }
        public string Planet { get; set; }
    }
}
