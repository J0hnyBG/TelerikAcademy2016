﻿namespace SuperheroesUniverse.Models.Enums
{
    public enum Alignment
    {
        Good = 0,
        Neutral,
        Evil
    }
}
