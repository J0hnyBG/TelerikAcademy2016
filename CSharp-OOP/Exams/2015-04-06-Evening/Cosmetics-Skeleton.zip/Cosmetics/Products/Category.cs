﻿using System.Linq;

namespace Cosmetics.Products
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Cosmetics.Common;
    using Cosmetics.Contracts;

    public class Category : ProductContainer, ICategory
    {
        private string _name;

        public Category(string name)
        {
            this.Name = name;
            this.ListOfProducts = new List<IProduct>();
        }

        public string Name
        {
            get { return _name; }
            set
            {
                Validator.CheckIfStringIsNullOrEmpty(value, string.Format(GlobalErrorMessages.StringCannotBeNullOrEmpty, "Category name"));
                Validator.CheckIfStringLengthIsValid(value, 15, 2, string.Format(GlobalErrorMessages.InvalidStringLength, "Category name", 2, 15));
                _name = value;
            }
        }

        public void AddCosmetics(IProduct cosmetics)
        {
            this.ListOfProducts.Add(cosmetics);
            this.ListOfProducts = this.ListOfProducts.OrderBy(x => x.Brand).ThenByDescending(x => x.Price).ToList();
        }

        public void RemoveCosmetics(IProduct cosmetics)
        {
            if (!this.ListOfProducts.Contains(cosmetics))
            {
                throw new ArgumentException($"Product {cosmetics.Name} does not exist in {this.Name}!");
            }
            this.ListOfProducts.Remove(cosmetics);
        }

        public string Print()
        {
            var sb = new StringBuilder();
            sb.Append($"{this.Name} category - {this.ListOfProducts.Count} products in total");
            foreach (var product in ListOfProducts)
            {
                sb.Append(product.Print());
            }

            return sb.ToString();
        }
    }
}
