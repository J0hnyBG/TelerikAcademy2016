﻿namespace TradeAndTravel
{
    public class Forest : Location
    {
        public Forest(string name)
            : base(name, LocationType.Forest)
        {
        }
    }
}
