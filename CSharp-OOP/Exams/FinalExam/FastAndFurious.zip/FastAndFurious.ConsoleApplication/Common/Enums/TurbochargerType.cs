﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum TurbochargerType
    {
        TwinTurbo,
        SequentialTurbo
    }
}
