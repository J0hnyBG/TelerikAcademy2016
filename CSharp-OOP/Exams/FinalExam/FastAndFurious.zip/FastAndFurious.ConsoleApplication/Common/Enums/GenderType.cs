﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum GenderType
    {
        NotSet = 0,
        Female,
        Male
    }
}
