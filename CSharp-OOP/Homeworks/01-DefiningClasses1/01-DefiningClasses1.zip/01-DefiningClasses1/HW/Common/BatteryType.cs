﻿namespace HW.Enum
{
    //Problem 3 - Enumeration
    public enum BatteryType
    {
        LiIon,
        NiMh,
        NiCd
    }
}