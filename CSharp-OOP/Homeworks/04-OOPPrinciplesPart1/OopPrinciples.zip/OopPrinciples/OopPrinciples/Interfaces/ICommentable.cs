﻿namespace OopPrinciples.Interfaces
{
    internal interface ICommentable
    {
        string Comment { get; set; }
    }
}
