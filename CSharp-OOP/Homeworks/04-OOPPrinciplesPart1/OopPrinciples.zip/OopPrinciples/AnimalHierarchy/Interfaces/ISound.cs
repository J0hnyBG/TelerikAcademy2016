﻿namespace AnimalHierarchy.Interfaces
{
    internal interface ISound
    {
        void ProduceSound();
    }
}
