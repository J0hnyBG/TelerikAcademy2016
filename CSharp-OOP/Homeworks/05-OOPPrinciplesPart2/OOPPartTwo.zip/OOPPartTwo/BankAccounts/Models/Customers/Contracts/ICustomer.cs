﻿namespace BankAccounts.Models.Customers.Contracts
{
    internal interface ICustomer
    {
        string Name { get; set; }
    }
}
