﻿namespace StudentClass
{
    public enum FacultiesEnum
    {
        AppliedScience,
        StatisticsAndInformatics,
        Juristic,
        Journalism,
        Pedagogics,
    }
}
