﻿namespace StudentClass
{
    public enum SpecialitiesEnum
    {
        Informatics,
        Economics,
        Mathematics,
        Biology,
        Law,
        BusinessAdministration,
        EnglishPhilology
    }
}
