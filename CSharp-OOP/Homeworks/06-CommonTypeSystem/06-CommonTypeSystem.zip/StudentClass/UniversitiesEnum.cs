﻿namespace StudentClass
{
    public enum UniversitiesEnum
    {
        Unss,
        Su,
        Tu,
        Oxford,
        Cambridge
    }
}
