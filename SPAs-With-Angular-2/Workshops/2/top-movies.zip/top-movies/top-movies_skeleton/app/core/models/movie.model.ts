import any = jasmine.any;
export class Movie {
    Title: string;
    Year: string;
    Rated: string;
    Released: string;
    Runtime: string;
    Genre: string;
    Director: string;
    Writer: string;
    Actors: string;
    Plot: string;
    Language: string;
    Country: string;
    Awards: string;
    Poster: string;
    Metascore: string;
    imdbRating: string;
    imdbVotes: string;
    imdbID: string;
    Type: string;
    Response: string;

    constructor() {
        Object.keys(Movie).forEach((key:string) => {
            let that = this;
            (<any>that)[key] = '';
        })
    }

    public get starRating():number {
        return Math.floor((+this.imdbRating / 2))
    }
}