import { Component } from '@angular/core';

@Component({
    templateUrl: 'footer.component.html',
    selector: 'mdb-footer'
})

export class FooterComponent {
    constructor() {
    }
}
